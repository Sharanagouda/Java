package method_overloading;

public class Samplee1 {
void test1()
{
	System.out.println("------------------------------------------");
	System.out.println("Running test1() of Sample1");
	System.out.println("------------------------------------------");
	
}
}
class Sample6 extends Samplee1
{
	void test1()
	{
		
		System.out.println("------------------------------------");
		System.out.println("test overriding");
		System.out.println("------------------------------------");
	}
}
