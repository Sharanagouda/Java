package method_overloading;

public class SampleMainClass1 {

	public static void main(String[] args) {
	System.out.println("--------------------------------");
	Sample1 ref1=new Sample1();
	ref1.test1();
	ref1.test1(13);
	ref1.test1(13.26);
	ref1.test1(15, 25.98);
	System.out.println("--------------------------------");
	}

}
