package method_overloading;

public class Sample2 {
	void disp() {
		System.out.println("Running disp() of Sample2 class");
	}
	}

	class Sample3 extends Sample2 {
		// method overloading
		void disp(int arg1) {
			System.out.println("Running disp(int) of sample3 class");
		}
	}
