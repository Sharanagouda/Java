package method_overloading;

public class SampleMainClasss1 {

	public static void main(String[] args) {
	System.out.println("main method started");
	Sample6 ref1=new Sample6();
	ref1.test1();
	System.out.println("main method ended");
	
	}

}
