package method_overloading;

public class Sample1 {
//Overloaded instance method
void test1()
{
	System.out.println("Running no arg test1() method");
}
void test1(int arg1)
{
	System.out.println("Running int arg test1() method");
}
void test1(double arg1)
{
	System.out.println("Running double arg test1() method");
}void test1(int arg1,double arg2)
{
	System.out.println("Running int,double args test1() method");
}
}
