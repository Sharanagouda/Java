package method_overloading;

public class SampleMainClasss2 {

	public static void main(String[] args) {
	System.out.println("main method started");
	Sample7 ref1=new Sample7();
	ref1.test1();
	ref1.test1(48);
	System.out.println("main method ended");
	}

}
