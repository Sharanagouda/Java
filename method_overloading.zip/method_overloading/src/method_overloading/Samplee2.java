package method_overloading;

public class Samplee2 {
	void test1() {
		System.out.println("------------------------------------------");
		System.out.println("Running test1() method");
		System.out.println("------------------------------------------");

	}
}

class Sample7 extends Samplee2 {
	void test1() {

		System.out.println("***********************************");
		System.out.println("overriding  test1() method");
		System.out.println("**************************************");
	}

	void test1(int arg1) {
		System.out.println("#########################################");
		System.out.println("overloaded test1() method");
		System.out.println("##############################################");
	}
}