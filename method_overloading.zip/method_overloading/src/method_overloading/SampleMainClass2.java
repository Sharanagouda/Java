package method_overloading;



public class SampleMainClass2 {

	public static void main(String[] args) {
		System.out.println("-----------------------------------");
	Sample3 ref1=new Sample3();
	ref1.disp();
	ref1.disp(85);
	System.out.println("---------------------");
	}

}
