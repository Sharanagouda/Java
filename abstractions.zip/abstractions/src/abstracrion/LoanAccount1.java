package abstracrion;
public abstract class LoanAccount1 implements Account{
	double accBal;

	LoanAccount1(double lnAmt) {
		System.out.println("Opening Loan Account");
		accBal = lnAmt;

	}

	void deposite(double amt) {
		System.out.println("Clearing loan with Rs: " + amt);
		accBal = accBal - amt;
	}

	void withdrawal(double amt) {
		System.out.println("availing more loan Rs : " + amt);
		accBal = accBal + amt;

	}

	void viewBalance() {
		System.out.println("Outstanding Balance Rs: " + accBal);
	}
}
