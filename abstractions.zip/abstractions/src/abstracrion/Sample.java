package abstracrion;

public class Sample {

}
