package arrays;

public class Car {
	String CarType;

	Car(String CarType) {
		this.CarType = CarType;
	}

	public String toString() {
		return CarType + "Car";
	}

}
