package arrays;
public class Pen1{
	String inkColor;
Pen1(String inkColor)
{
	this.inkColor=inkColor;
}

public void Pen(String inkColor2) {
}

public String toString()
{
	return inkColor +"pen";
}
}
