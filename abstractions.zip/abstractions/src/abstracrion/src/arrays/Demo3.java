package arrays;

public class Demo3 {

	public static void main(String[] args) {
System.out.println("********************************************88");
Pen1[] penstand=new Pen1[5];
System.out.println("Total capacity:"+penstand.length);
penstand[0]=new Pen1("Blue");
penstand[1]=new Pen1("Black");
penstand[2]=new Pen1("red");
penstand[3]=new Pen1("Green");
penstand[4]=new Pen1("Pink");
System.out.println("Pen available are");
for(int i=0;;i++)
{
	System.out.println(penstand[i]);
}
	}

}
