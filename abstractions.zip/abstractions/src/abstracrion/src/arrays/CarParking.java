package arrays;

public class CarParking {

	int Spacecount1 = 0;
	void CarParking(Car[] Parking) {

		{
			
			for (Car c1 : Parking) {
				if (c1 != null) {
					Spacecount1++;
				}
			}
			System.out.println("Total available Space to Park car " + Spacecount1++);
		}
	}

	void TotalCapacity(Car[] Parking) {
		System.out.println("Total capacity to park:" + Parking.length);
	}

	void displayCars(Car[] Parking) {
		System.out.println("Cars are......");
		for (Car c1 : Parking) {
			if (c1 != null) {
				{
					System.out.println(c1);

				}
			}
		}
	}
}