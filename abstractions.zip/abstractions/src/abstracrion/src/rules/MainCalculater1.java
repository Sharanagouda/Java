package rules;

public class MainCalculater1 {

	public static void main(String[] args) {
		System.out.println("************************************************");
		Calculater calsi1=Calculater.getInstance();
		calsi1.devide(12, 4);
		Calculater calsi2=Calculater.getInstance();
		calsi2.devide(42, 6);
		Calculater calsi3=Calculater.getInstance();
		calsi3.devide(25, 5);
		System.out.println("************************************************");
			}

	}

