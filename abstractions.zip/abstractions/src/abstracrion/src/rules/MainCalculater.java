package rules;

public class MainCalculater {

	public static void main(String[] args) {
System.out.println("************************************************");
Calculater calsi1=Calculater.getInstance();
calsi1.devide(12, 4);
Calculater calsi2=Calculater.getInstance();
calsi2.devide(37, 6);
Calculater calsi3=Calculater.getInstance();
calsi3.devide(125, 5);
System.out.println("************************************************");
	}

}
