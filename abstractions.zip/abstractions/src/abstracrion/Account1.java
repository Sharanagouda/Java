package abstracrion;


public class Account1 {
	double accBal;

	Account1(double intiAmt) {
		System.out.println("Opening accoutn with Rs:" + intiAmt);
		accBal = intiAmt;
	}

	void deposit(double amt) {
		System.out.println("depositing Rs:" + amt);
		accBal = accBal + amt;
	}

	void withdrawal(double amt)

	{
		System.out.println("withdrawal Rs:" + amt);
		accBal = accBal - amt;
	}

	void viewBalance() {
		System.out.println("Balance is:" + accBal);
	}
}
