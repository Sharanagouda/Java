package abstracrion;

public class MainTestAccount {

	public static void main(String[] args) {
		System.out.println("*******************************");
		ATMMachine atm1 = new ATMMachine();
		Account1 acc1 = Bank.getAccount('L');
		atm1.ATMMachine(10000.00);
		System.out.println("********************************");
	}

}
