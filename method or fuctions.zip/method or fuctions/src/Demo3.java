public class Demo3 {

	public static void main(String[] args) {

		System.out.println("main method started");
		Demo3(2, 5.6);
		Demo3(36, 4.3);
		System.out.println("main method ended");

	}

	static void Demo3(int arg1, double arg2) {
		System.out.println("Running Demo3() method");
		System.out.println("arg1 value :" + arg1);
		System.out.println("arg2 value :" + arg2);
	}
}
