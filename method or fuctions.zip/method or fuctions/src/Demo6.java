
//                       Square a number
public class Demo6 {
	static int Demo6(int num1) {
		System.out.println("Calculating Square of :" + num1);
		int res1 = num1 * num1;
		return res1;
	}

	public static void main(String[] args) {
		System.out.println("main method started");
		int k = Demo6(9);
		System.out.println("Square is :" + k);
		System.out.println("---------------------------");
		k = Demo6(4);
		System.out.println("Square is :" + k);
		System.out.println("main method ended");
	}

}
