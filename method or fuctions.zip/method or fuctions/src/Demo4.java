
//                        Square a number
public class Demo4 {
	static void Demo4(int num1) {
		System.out.println("Calculating square :" + num1);
		int res1 = num1 * num1;
		System.out.println("Square is :" + res1);
		return;
	}

	public static void main(String[] args) {
		System.out.println("main method started");
		Demo4(6);
		System.out.println("-----------------------");
		Demo4(7);
		System.out.println("main method ended");
	}

}
