// Area and Circumference of circle 
public class Demo8 {
	final static double pi = 3.142;

	static double area(double rad) {
		System.out.println("calculating area of circle radius");
		double a1 = pi * rad * rad;
		return a1;

	}

	static double Circumference(double rad) {
		System.out.println("Calculating Circumference of circle of radius");
		double a1 = 2 * pi * rad;
		return a1;
	}

	public static void main(String[] args) {
		System.out.println("main method started ");
		System.out.println("Area of Circle :" + area(3.2));
		System.out.println("Circumference of circle :" + Circumference(3.6));
		System.out.println("main method ended");
	}

}
