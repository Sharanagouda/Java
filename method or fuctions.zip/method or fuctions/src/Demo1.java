public class Demo1 {
	static void Demo1() {
		System.out.println("Running Demo1()method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("main method started");
		Demo1();// method invocatiom
		Demo1();
		System.out.println("main method ended");
	}

}
