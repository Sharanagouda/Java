public class Demo2 {
	static void Demo2(int arg1) {

		System.out.println("Running Demo2() method");
		System.out.println("arg1 value:" + arg1);
		return;// go back to place from where called
	}

	public static void main(String[] args) {

		System.out.println("main method started");
		Demo2(12);
		Demo2(34);
		System.out.println("main method ended");

	}

}
