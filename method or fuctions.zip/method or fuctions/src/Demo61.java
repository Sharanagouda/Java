
//                           Square a number same as Demo6 here is a small defference
public class Demo61 {

	static int Demo61(int num1) {
		System.out.println("Calculating Square of :" + num1);
		int res1 = num1 * num1;
		return res1;
	}

	public static void main(String[] args) {
		System.out.println("main method started");
		System.out.println("Square is :" + Demo61(3));
		System.out.println("---------------------------------");
		System.out.println("Square is :" + Demo61(7));
		System.out.println("main method ended");
	}
}
