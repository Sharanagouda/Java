public class Demo5 {
	static int Demo5() {
		System.out.println("Running Demo5() method");
		return 64;
	}

	public static void main(String[] args) {
		System.out.println("main method started");
		int k = Demo5();// Returned value is assigned to k
		System.out.println("k value:" + k);
		System.out.println("main method ended");
	}

}
