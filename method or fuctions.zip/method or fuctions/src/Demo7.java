
//Square a number
public class Demo7 {
	static int res1;// globle variable

	static int Square(int num1) {
		System.out.println("Calculating square of :" + num1);
		res1 = num1 * num1;
		return res1;
	}

	public static void main(String[] args) {
		System.out.println("main method started");
		Square(6);
		System.out.println("Square is :" + res1);
		System.out.println("main method ended");

	}

}
