package interview_Programs;

public class SubStringDemo {
	public static void main(String[] args) {
		
	
	String text = "iMac"; 
	String withoutFirstCharacter = text.substring(1); 
	// index starts at zero 
	String withoutLastCharacter = text.substring(0, text.length() - 1); 
	
	System.out.println("Using SubString() method: ");
	System.out.println("input string: " + text); 
	System.out.println("without first character: " + withoutFirstCharacter);
	System.out.println("without last character: " + withoutLastCharacter); 
	// 2nd Example - You can use StringBuffer or StringBuilder to remove 
	// first or last character from String in Java
//	String iStore = "iCloud"; 
//	// converting String to StringBuilder
//	StringBuilder builder = new StringBuilder(iStore);
//	// removing first character builder.deleteCharAt(0); 
//	System.out.println("Using StringBuilder deleteCharAt() method: "); 
//	System.out.println("input string: " + iStore); 
//	System.out.println("String after removing first character: " + builder.toString());
//	// creating another
//	StringBuilder builder1 = new StringBuilder(iStore); 
//	// removing last character from 
//	String builder11.deleteCharAt(iStore.length() - 1);
//	System.out.println("String after removing last character: " + builder.toString()); } 

	//javarevisited.blogspot.com/2016/03/how-to-remove-first-and-last-character-from-String-in-java-example.html#ixzz42skPLJLj
}}