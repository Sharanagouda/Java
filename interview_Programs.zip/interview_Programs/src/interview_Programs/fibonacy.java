package interview_Programs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class fibonacy {
	public static void main(String[] args) throws NumberFormatException, IOException {
		// accept how many fibonaccy needed
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("How many fibonuccy ?");
		int n = Integer.parseInt(br.readLine());

		// take a first two fibonaccies as 0 and 1
		long f1 = 0, f2 = 1;

		System.out.println(f1);
		System.out.println(f2);
		// find the next fibonaccci
		long f = f1 + f2;
		System.out.println(f);
		//already 3 fibonaci are  displayed so count will start from 3
		int count = 3;
		while (count < n) {
			f1 = f2;
			f2 = f;
			f = f1 + f2;
			System.out.println(f);
			count++;

		}

	}
}
