package interview_Programs;

public class Palindrome {

	public static void main(String[] args) {
		String str="MADAM";
		String revstring="";
		 
		for(int i=str.length()-1;i>=0;--i){
		revstring +=str.charAt(i);
		}
		 
		System.out.println("After Reversing "+revstring);
		 
		if(revstring.equalsIgnoreCase(str)){
		System.out.println("This string is a Palindrome");
		}
		else{
		System.out.println("This String is Not Palindrome");
		}
		 
	}

}
