package ps;
interface cars
{
	int carvalue();

}

class audicar implements cars
{
	public int carvalue()
	{
		return 1;
	}
}

class benzcar implements cars
{
	public int carvalue()
	{
		return 2;
	}
}

class maruticar implements cars
{
	public int carvalue()
	{
		return 3;
	}
}

