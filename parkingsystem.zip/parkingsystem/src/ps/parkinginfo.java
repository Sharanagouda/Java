package ps;
class parkinginfo
{
	int[] sn=new int[20];
	int avl=0, pkd=0,j=0, audi=0,benz=0,maruti=0;
	cars[] arg;
	parkinginfo(cars[] arg)
	{
		this.arg=arg;
	}
	void capacity()
	{
		System.out.println("Total parking capacity is"+arg.length);
		
	}
	void parked()
	{
		for (int i = 0; i < arg.length; i++) 
		{
			if(arg[i]!=null)
			{
				pkd++;
			}
			else
			{
				sn[j]=i+1;
				j++;
			}
		}
		System.out.println("Currently parked cars"+pkd);
	}
	void available()
	{
		avl=arg.length-pkd;
		System.out.println("Available parking slots"+avl);
	}
	void details()
	{
		for (int i = 0; i < arg.length; i++) 
		{
			if(arg[i]!=null)
			{
				int s=arg[i].carvalue();
				if(s==1)
				audi++;
				else if(s==2)
					benz++;
				else if(s==3)
					maruti++;
				else
				{
					System.out.println("a new type of car found");
				}
			}
			
		}
		System.out.println("No. of Audi cars  "+audi);

		System.out.println("No. of Benz cars  "+benz);
		System.out.println("No. of maruti cars  "+maruti);
	}
	void parkingslots()
	{
		System.out.println("Available parking slots are");
		for (int i = 0; i < sn.length; i++) 
		{
			if(sn[i]>0)
			{
				System.out.print(sn[i]+"  ");
			}
		}
		System.out.println();
		
	}
	void selectslot(int slot)
	{
		int a=1;
		if(slot>0)
		for (int i = 0; i < arg.length; i++) 
		{
			if(sn[i]==slot)
			{
				System.out.println("Slot No."+slot+" is selected");
				a--;
			}
			
		}
		if (a==1)
		System.out.println("Invalid slot");
	}
}
