package ps;
public class parking
{
	public static void main(String[] args) 
	{
		
	}
}

