package ps;
import java.util.Scanner;
public class park {

	public static void main(String[] args) 
	{
		System.out.println("JSPIDERS car parking system\n");
		cars[] arr=new cars[20];
		arr[1]=new audicar();
		arr[3]=new audicar();
		arr[5]=new audicar();
		arr[7]=new audicar();
		arr[8]=new benzcar();
		arr[10]=new benzcar();
		arr[15]=new benzcar();
		arr[18]=new maruticar();
		parkinginfo p=new parkinginfo(arr);
		p.capacity();
		p.parked();
		p.available();
		p.details();
		p.parkingslots();
		System.out.println("select the slot\n");
		Scanner sq1=new Scanner(System.in);
		int q=sq1.nextInt();
		p.selectslot(q);
		System.out.println("\n\nThank you");

	}

}
