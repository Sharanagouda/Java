package ps;
import java.util.Scanner;
interface CarPark
{
	public String toString();
}

class Audi implements CarPark
{
	String Brand;
	Audi(String Brand)
	{
		this.Brand=Brand;
	}

	public String toString()
	{
		return Brand +" is parked";
	}
}
class Benz implements CarPark
{
	String Brand;
	Benz(String Brand)
	{
		this.Brand=Brand;
	}
	public String toString()
	{
		return Brand +" is parked";
	}
}
class Maruthi implements CarPark
{
	String Brand;
	Maruthi(String Brand)
	{
		this.Brand=Brand;
	}

	public String toString()
	{
		return Brand +" is parked";
	}
}
class Nano implements CarPark
{
	String Brand;
	Nano(String Brand)
	{
		this.Brand=Brand;
	}

	public String toString()
	{
		return Brand +" is parked";
	}
}
class Honda implements CarPark
{
	String Brand;
	Honda(String Brand)
	{
		this.Brand=Brand;
	}

	public String toString()
	{
		return Brand +" is parked";
	}
}




