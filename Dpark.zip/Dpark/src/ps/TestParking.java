package ps;

public class TestParking
{
	public static void main(String[] args)
	{
		System.out.println("Jspiders Car Parking System");
		System.out.println("***************************\n");
		CarPark[] car=new CarPark[20];
		car[13]= new Audi("Audi");
		car[1]= new Benz("Benz");
		car[2]= new Maruthi("Maruthi");
		car[3]= new Audi("Audi");
		car[4]= new Nano("Nano");
		car[5]= new Benz("Benz");
		car[6]= new Nano("Nano");
		car[7]= new Maruthi("Maruthi");
		car[8]= new Honda("Honda");
		car[10]= new Honda("Honda");
		car[19]= new Benz("Benz");
		car[16]= new Maruthi("Maruthi");
		car[15]= new Nano("Nano");
		car[14]= new Benz("Benz");
		car[18]= new Audi("Audi");

		Park pp=new Park();
		pp.TotalParkingSpace(car);
		pp.AlreadyParked(car);
		pp.AvailableSlots(car);
		pp.NewEntry(car);
		
		System.out.println("\n�D7");
	}
}


