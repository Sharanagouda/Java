package ps;
import java.util.Scanner;
public class Park
	{
		void TotalParkingSpace(CarPark[] cp)
		{
			System.out.println("Total Parking Space is: "+cp.length + "\n");
		}

		void AlreadyParked(CarPark[] cp)
		{
			int location=0,count=0;
			for(CarPark c1:cp)
			{

				if(c1 !=null)
				{
					location++;
					count++;
					System.out.println(c1 +" @ slot: "+location);
				}
				else
				{
					location++;
				}
			}
			System.out.println();
			System.out.println("Total parked cars: "+count);
			System.out.println("Empty Parking Slots are: "+(cp.length-count)+ "\n");
		}

		void AvailableSlots(CarPark[] cp)
		{   
			int Location=0;

			for(CarPark c1:cp)
			{
				if(c1!=null)
				{
					Location++;
				}
				else
				{
					Location++;
					System.out.print(Location+ " ");
				}
			}
			System.out.println(" These all are available parking slots");

		}
		void NewEntry(CarPark[] cp)
		{
			System.out.println("Select Parking Position");
			Scanner sc1=new Scanner(System.in);
			int n1=sc1.nextInt();
			int count=0;
			for(CarPark cn:cp)
			{
				if(n1>20 || n1<1)
				{
					System.out.println("This is invalid parking slot");
					break;
				}
				if(cn!=null)
				{
					count++;
				}
				else
				{
					count++;
					if(count==n1)
					{
						System.out.println(n1 + " :Parking slot is confirmed");
						break;
					}
				}
				if(count>19)
					{
						System.out.println("Sorry!,This Parking slot is already resreved ");
						break;
					}
			}
		}
	}
