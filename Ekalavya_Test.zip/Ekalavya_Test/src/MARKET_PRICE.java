import java.util.Scanner;
import java.util.Formatter;

public class MARKET_PRICE {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		double Grade1, Grade2, Grade3, AvgPrice;
		
		System.out.println("Enter Name of Items");
		int n = sc.nextInt();
		
		for(int i = 1; i <= n; i++) {
			System.out.println("Enter Number of Items");
			String name = sc.nextLine();
			System.out.println("Enter Grade1");
			Grade1 = sc.nextDouble();
			System.out.println("Enter Grade2");
			Grade2 = sc.nextDouble();
			System.out.println("Enter Grade3");
			Grade3 = sc.nextDouble();
			AvgPrice = (Grade1 + Grade2 + Grade3) / 3;
			
			for (int j = 1; j ==i; j++) {
				System.out.println("__________________________________________________________________");
				System.out.println("             PRICE LIST (Rate Rs/Kg.)                             ");
				System.out.println("__________________________________________________________________");
				System.out.println("Iten Name      Grade I      Grade II       Grade III      Avg.Price");
				for (int j2 = 0; j2 <= n; j2++) {
					System.out.print(name+"      " + Grade1 + "      " + Grade2 + "     " + Grade3 + "      " + AvgPrice);
				}
				
			}
			
			

		}

	}

}
