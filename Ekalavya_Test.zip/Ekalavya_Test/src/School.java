import java.util.Scanner;


public class School {

	public static void main(String[] args) {
		int SumOfBoys=0;
		int SumOfGirls=0;
		
	 	Scanner sc=new Scanner(System.in);
    	int ClassNo=sc.nextInt();
    	int NoOfBoys=sc.nextInt();
    	SumOfBoys=SumOfBoys+NoOfBoys;
    	int NoOfGirls=sc.nextInt();
    	SumOfGirls=SumOfGirls+NoOfGirls;
    	int Total=NoOfBoys+NoOfGirls;
		System.out.println("_______________________________________________________________________________________");
		System.out.println("                              SCHOOL   STATISTICS                                   ");
		System.out.println("_______________________________________________________________________________________");
        System.out.println("     Class No                No. of Boys               No. of Girls        Total No. " );
    	System.out.println("_______________________________________________________________________________________");
    	System.out.println("       "+ClassNo+"                       "+NoOfBoys+"                             "+NoOfGirls+"            "+Total);
    	
    	System.out.println("Total No Of Students in a Class "+(SumOfBoys+SumOfGirls));
	}

}
