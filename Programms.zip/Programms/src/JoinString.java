//Given string  a and b return a string both string exp a=abc b=xyz output=abcxyz
import java.util.Scanner;

public class JoinString {

	public static void main(String[] args) {
		String S1,S2,S3 = "";
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter two Strings or Same length");
	S1=sc.nextLine();
	S2=sc.nextLine();
	
	if(S1.length()==S2.length()){
		for(int i=0;i<S1.length();i++)
		{
			S3=S3+S1.charAt(i)+S2.charAt(i);
			
		}
		System.out.print(S3);
	}
	else{
		System.out.println("Length of the Strings are not Sames");
	}
	
	}

}
