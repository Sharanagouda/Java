//Given a String return a string where for every char in original string there are two char like exp input=the output=tthhee
import java.util.Scanner;
public class MixingStrings {

	public static void main(String[] args) {
		
	String S1,S2=" ";
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter  String ");
	S1=sc.nextLine();
	for(int i=0;i<S1.length();i++)
	{
		S2=S2+S1.charAt(i)+S1.charAt(i);
	}
	System.out.println(S2);

	}

}
