
public class ReverseEachWorld {
	static void reverseWordEachOfString(String inputString)
	{
		String[] words=inputString.split(" ");
		String reversestring="";
		for(int i=0;i<words.length;i++);
		{
			String word=words[i];
			String reverseword="";
			for(int j=words.length-1;j>=0;j--){
				reverseword=reverseword+word.charAt(j);
			}
	reversestring=reversestring+reverseword+"";
	}
		System.out.println(inputString);
		System.out.println(reversestring);
		System.out.println("====----------------------------------------------===");
		
		}
		
	

	public static void main(String[] args) {
		reverseWordEachOfString("I am java Programmer");

	}

}
