//Given an array of ints, return true if the value 3 appears in the array exactly 3 times and 3's are next to each other
public class ReturnTrue {

	public static void main(String[] args) {
		int[] a = { 2, 3, 3, 3, 5 };
		for (int i = 0; i < a.length - 1; i++) {
			if (a[i] == a[i + 1]) {
				if (a[i] == a[i + 2]) {
					if (a[i] == 3)

					{
						System.out.println("TRUE");
						System.exit(0);
					}
				}
			}
		}
		System.out.println("FALSE");
	}
}
