//Write a java program to reverse word exp=intput This is India output=India is This
import java.util.Scanner;

public class ReverseWord {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the String");
	String S = sc.nextLine();
	String[] word=S.split(" ");
	for(int i=word.length-1;i>=0;i--)
	{
		System.out.print(word[i]+" ");
	}

	}

}
