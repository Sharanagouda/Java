//Given an array of int Shift one element by left side ex:input 2,3,4,5,6 output=3,4,5,6,2
import java.util.Arrays;

public class ShiftoneElement {

	public static void main(String[] args) {

		int[] a = { 2, 3, 4, 5, 6 };
		int temp = a[0];
		for (int i = 0; i < a.length - 1; i++) {
			a[i] = a[i + 1];
            
		}
		
		System.out.print(Arrays.toString(a));
		System.out.print(temp);

	}

}
