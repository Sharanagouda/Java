package labtest1;

public class Pallindrome 
{
	public static void main(String[] args) {
		int a=242;
		int n=a,b=a,rev=0;  
		while(n>0)
		{
			a=n%10;
			rev=rev*10+a;
			n=n/10;	
		}
		if(rev==b)
			System.out.println("Its a Palindrom");
		else
			System.out.println("Its not a Palindrom");
	}

}
