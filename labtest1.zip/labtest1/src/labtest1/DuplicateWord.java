package labtest1;

import java.util.HashMap;
import java.util.Scanner;

public class DuplicateWord {
	public static void main(String[] args) {
		
	System.out.println("Enter the string");
    Scanner sc = new Scanner(System.in);

    String s=sc.nextLine();

    String[] words = s.split(" ");

    HashMap<String, Integer> wordDuplicateCount = new HashMap<String, Integer>();

    int count;
    {
    for (int i = 0; i < words.length; i++)
    {
        count = 0;

        for (int j = 0; j < words.length; j++)
        {
            if(words[i].equalsIgnoreCase(words[j]))
            {
                count++;
            }
        }

        if(count > 1)
        {
            wordDuplicateCount.put(words[i].toLowerCase(), count);
        }
    }

    System.out.println(wordDuplicateCount);
}

}
}