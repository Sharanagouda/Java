package labtest1;

public class ReverseNumber {
 public static void main(String[] args) {
	
}
}
