package labtest1;

public class Fact 
{
	static int fact(int num)
	{
		int fact=1;
		for (int i=1;i<=num;i++)
		{
			fact=fact*i;
		}
		return fact;
	}

	public static void main(String[] args)
	{
		int result=fact(5);
		System.out.println("Factorial result : "+result);

	}

}
