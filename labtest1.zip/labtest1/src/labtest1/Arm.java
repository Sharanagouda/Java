package labtest1;

public class Arm {

	public static void main(String[] args) {
		int n=153,c=0,a,d;//153,371
		d=n;
		while(n>0)
		{
			a=n%10;
			n=n/10;
			
			c=c+(a*a*a);
			}
			if(d==c)
				System.out.println("armstrong number");
			else
			System.out.println("this is not armstrong number"); 
			
	}
	  
		

}
