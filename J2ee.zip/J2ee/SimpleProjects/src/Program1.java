import java.sql.*;

import java.util.Scanner;


public class Program1 {

	public final static String URL = "jdbc:mysql://localhost:3306?user=root&password=sharanu";
	public final static String DRIVER = "com.mysql.jdbc.Driver";

	public static void main(String[] args) {
		java.sql.Connection conn = null;
		java.sql.Statement stmt = null;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Student id");
		int id=scan.nextInt();
		System.out.println("Enter Student name");
		String name=scan.next();
	 System.out.println("Enter the stream");
		String stream=scan.next();
		System.out.println("Enter the percentage");
		double perc=scan.nextDouble();
		scan.close();
		String InsertQry="insert into jjm13.student values (10,'ram','CSE',99.54);"
;
		try {
			Class.forName(DRIVER);
			conn =  DriverManager.getConnection(URL);
			stmt =  conn.createStatement();
			boolean res = stmt.execute(InsertQry);
			if (!res) {
				int nores = stmt.getUpdateCount();
				System.out.println(nores + "Record inserted");

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();

				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
		}

		
	}
	}
