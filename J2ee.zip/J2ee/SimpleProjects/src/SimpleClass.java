import java.sql.*;

public class SimpleClass {
	public static void main(String[] args) {
		/*
		 * Connection con= null; 
		 * Statement st=null;
		 */

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=sharanu");
			Statement st = con.createStatement();
			int rs = st
					.executeUpdate("insert into jjm13.employeetable values (13,'Management',21,'Sangam','Manager',6487.24,2006-08-20)");
			System.out.println(rs + "record updated successfully");
			
		} catch (Exception e) {
			e.printStackTrace();
		}/*finally {
			try {
				if (st != null) {
					st.close();

				}
				if (con != null) {
					con.close();
				}*/

	}}
