package com.sharanu.sampleapp;

public class Bike {
	public static void main(String[] args) {
		System.out.println("Bike ride...");
	}

}
