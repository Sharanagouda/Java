package com.sharanu.sampleapp;
/*Factory/Helper Class*/
public class VehicalFactory {
	/*Factory/Helper Method*/	
	static public void main(String[] args)
	{
		if(type.equals("Bike"))
		{
			return new BikeVehical();
		}
		else if(type.equals("Car"))
		{
			return new CarVehical();
		}
		else
		{
			System.out.println("Error type Proper Vehical");
		}
	}

}
