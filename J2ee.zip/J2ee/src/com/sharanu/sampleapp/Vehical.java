package com.sharanu.sampleapp;

public class Vehical {
	public static void getVehical(String type)
	{
		if(type.equals("Bike"))
		{
			return new Vehical();
			
		}
		else if (type.equals("Car"))
		{
			return new Vehical();
			
		}
	}

}
