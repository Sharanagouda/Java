package com.sharanu.sampleapp;

public class Car {
public static void main(String[] args) {
	System.out.println("Car driving....");
}
}
