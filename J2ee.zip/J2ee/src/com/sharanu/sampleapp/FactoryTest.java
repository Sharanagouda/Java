package com.sharanu.sampleapp;

import java.util.Scanner;
public class FactoryTest {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the Vehical");
		String type=scan.next();
		Vehical v=VehicalFactory getVehical(type);
		if( v instanceof Car)
		{
			Car cr=(Car) v;
			cr.drive();
			
		}else{
			Bike b=(Bike) v;
			b.ride();
		}
		
		
		
	}

}
