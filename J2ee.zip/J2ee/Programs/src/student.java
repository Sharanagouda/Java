import java.sql.*;
import java.util.Scanner;


public class student {
	public final static String URL="jdbc:mysql://localhost:3306?username=root&password=sharanu";
	public final static String DRIVER="com.mysql.jdbc.Driver";
	
public static void main(String[] args) {
	Connection con=null;
	Statement stmt=null;
	Scanner scan=new Scanner(System.in);
	System.out.println("enter student id");
	int id=scan.nextInt();
	scan.close();
	try {
		Class.forName(DRIVER);
		con=DriverManager.getConnection(URL);
		stmt=con.createStatement();
		Boolean res=stmt.execute("select* from jjm13.student where sid'"+id+"'");
		if(res){
			ResultSet rs=stmt.getResultSet();
			if(rs.next()){
				String name=rs.getString(1);
				String Branch=rs.getString("Stream");
				double perc=rs.getDouble("perc");
				System.out.println(name+" "+Branch+" "+perc);
			}
		}
	} catch (Exception e) {
		
		e.printStackTrace();
	}finally {
		try {
			if (stmt != null) {
				stmt.close();

			}
			if (con != null) {
				con.close();
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	
	
}
}
}