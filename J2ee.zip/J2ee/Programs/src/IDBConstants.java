public interface IDBConstants {

	String URL = "jdbc:mysql://localhost:3306?user=root&password=sharanu";
	String DRIVER = "com.mysql.jdbc.Driver";

}
