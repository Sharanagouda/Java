import java.sql.*;
public class ConnectEx {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/jjm13","root","sharanu");
			PreparedStatement ps = con.prepareStatement("select*from student");
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				int id = rs.getInt("sid");
				String name = rs.getString("sname");
				String strm = rs.getString("stream");
				double per = rs.getDouble("perc");
				
				System.out.print("SID:"+id);
				System.out.println("");
				
				System.out.print("SNAME:"+name);
				System.out.println("");
				System.out.print("STREAM:"+strm);
				System.out.println("");
				System.out.print("PERCENTAGE:"+per);
				System.out.println("");
				System.out.println("------------------------");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		

	}

}
