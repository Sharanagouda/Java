import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class InsertEnmployee {
	public final static String URL = "jdbc:mysql://localhost:3306?user=root&password=sharanu";
	public final static String DRIVER = "com.mysql.jdbc.driver";

	public static void main(String[] args) {
		java.sql.Connection conn = null;
		java.sql.Statement stmt = null;
		String InsertQry = "insert into jjm13.employeetable values (3,'Sales',10,'Suresh','Manager',9875.26,2006-05-26)";
		try {
			Class.forName(DRIVER);
			conn =  DriverManager.getConnection(URL);
			stmt =  conn.createStatement();
			boolean res = stmt.execute(InsertQry);
			if (!res) {
				long nores = stmt.getLargeUpdateCount();
				System.out.println(nores + "Record inserted");

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();

				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
		}

	}

}
