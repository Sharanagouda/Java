import java.sql.*;

public class BatchStateDemo {
	public static void main(String[] args) {
		
		Connection con=null;
		Statement stmt= null;
		String InstertQry="insert jjm13.employee values (6,'Rohini','Testing',18650)";

		String UpdateQry="update jjm13.student set perc=82.2 where sid=7";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=sharanu");
			stmt=con.createStatement();
			/*add DB statement to Batch*/
			stmt.addBatch(InstertQry);
			stmt.addBatch(UpdateQry);
			int[] result=stmt.executeBatch();
			for (int i:result) {
				System.out.println(i+" ");
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			//close con
		}
	}

}
