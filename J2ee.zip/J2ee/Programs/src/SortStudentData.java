import java.sql.*;
import java.util.Scanner;
public class SortStudentData {
	public final static String URL=("jdbc:mysql://localhost:3306?user=root&password=sharanu");
	public final static String DRIVER="com.mysql.jdbc.Driver";
	
	public static void main(String[] args) {
		Connection con=null;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the percentage");
		double perc=scan.nextDouble();
		scan.close();
		
	try {
		Class.forName(DRIVER);
		con=DriverManager.getConnection(URL);
		PreparedStatement pstmt=con.prepareStatement("insert into jjm13.student values (15,'Ramu','DipEC',55.6)");
		pstmt.executeUpdate();
		System.out.println();
	} catch (Exception e) {
		e.printStackTrace();
	}finally{
		try{
			if(con!=null)
				con.close();
		}
	catch(SQLException ea)
{
		ea.printStackTrace();
}	

	

	}	
		
	
}}