public abstract class Demo2 {

	abstract void test1();

	abstract void test2();

}

class Sample extends Demo2 {
	void test1() {
		System.out.println("test1() of defind in Sample ");

	}

	void test2() {
		System.out.println("test2() of defind in Sample");
	}
}