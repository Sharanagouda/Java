abstract public class Demo3 {

	abstract void disp();

	abstract void test();
}

abstract class Sample1 extends Demo3 {
	void disp() {
		System.out.println("disp() defind in Sample1 class");
	}
}

class Sample2 extends Sample1 {
	void test() {
		System.out.println("test() defind in Sample2 class");
	}
}
