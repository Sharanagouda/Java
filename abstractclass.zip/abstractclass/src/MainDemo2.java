public class MainDemo2 {
	public static void main(String[] args) {
		System.out.println("----------------------------------");
		Sample ref1 = new Sample();
		ref1.test1();
		ref1.test2();
		System.out.println("-------------------------------------------");
		Demo2 ref2 = new Sample();
		ref2.test1();
		ref2.test2();
		System.out.println("---------------------------------");
	}

}
