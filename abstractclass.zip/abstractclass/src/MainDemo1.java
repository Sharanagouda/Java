public class MainDemo1 {

	public static void main(String[] args) {
		System.out.println("----------------------------------------------");
		Demo1.test3();
		// Demo1.d1=new Demo1();
		// Cannot create an object of abstract class
		System.out.println("-----------------------------------------------");
	}

}
