package abstractclass;

public abstract class Demo5 {
	void Demo5() {
		System.out.println("Running Constructor of abstract class");

	}

	void test1() {
		System.out.println("Concrete method of abstract class");

	}
}

class Sample2 extends Demo5 {
	Sample2() {
		super();
		System.out.println("Running Constructor of abstract class");
	}
}
