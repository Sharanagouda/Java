package abstractclass;

public class Demo4 {
	void test() {
		System.out.println("Concrete method of abstract");

	}
}

class Sample extends Demo4 {

}
