package abstractclass;

public class MainDemo4 {

	public static void main(String[] args) {
		System.out.println("-------------------------------------------------");
		Sample ref1 = new Sample();
		ref1.test();
		System.out.println("--------------------------------------------------");

	}

}
