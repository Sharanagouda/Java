package abstractclass;

public class MainDemo6 {

	public static void main(String[] args) {
		System.out.println("-----------------------------------------");
		Sample2 ref1 = new Sample2();
		ref1.test1();
		System.out.println("------------------------------------------");

	}

}
