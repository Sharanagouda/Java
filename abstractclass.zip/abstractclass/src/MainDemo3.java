public class MainDemo3 {

	public static void main(String[] args) {
		System.out.println("--------------------------------------------");
		Demo3 ref1 = new Sample2();
		ref1.disp();
		ref1.test();
		System.out.println("--------------------------------------------");

	}

}
