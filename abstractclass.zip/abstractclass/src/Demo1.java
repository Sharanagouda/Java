abstract public class Demo1 {
	void test1() {
		System.out.println("Concrete method");

	}

	static void test3() {
		System.out.println("Static method");

	}

	abstract void test2();
}
