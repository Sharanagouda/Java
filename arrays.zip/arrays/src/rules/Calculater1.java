package rules;

public class Calculater1 {
	
private static int count ;
private static Calculater1 c1;
	private Calculater1 (){
		System.out.println("Running Calcualter constructor....");
count++;
	}
	void devide (int num1,int num2)
	{
		System.out.println("deviding "+num1+" by "+num2);
		int res=num1/num2;
		System.out.println("Ressult :"+res);
	}
 static Calculater1 getInstance() 
	{
		if(count==0){
			c1=new Calculater1();
		}
		return c1;
	}
}
