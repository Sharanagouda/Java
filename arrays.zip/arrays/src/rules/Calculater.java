package rules;

public class Calculater {
private Calculater (){
	System.out.println("Running Calcualter constructor....");

}
void devide (int num1,int num2)
{
	System.out.println("deviding "+num1+" by "+num2);
	int res=num1/num2;
	System.out.println("Ressult :"+res);
}
static Calculater getInstance() 
{
	return new Calculater();
}
}
