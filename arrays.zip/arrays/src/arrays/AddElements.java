package arrays;

import java.util.ArrayList;
import java.util.Iterator;

public class AddElements {

	public static void main(String[] args) {

		ArrayList<String> al=new ArrayList<String>();
	al.add("Sharanu");
	al.add("raghav");
	al.add("hi");
	al.add(1,"dasfa");
	Iterator itr=al.iterator();
	while(itr.hasNext()){
		System.out.print(itr.next()+" ");
		
	}
	System.out.println();
	System.out.println(al.size());
	//we can use foreach loop also to access
	for(String obj:al){
		System.out.print(obj+" ");
	}

}}
