package arrays;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class Sort {

	public static void main(String[] args ){
		System.out.println("-------------------------------------------------------");
		int[] arr1;
		
		Scanner sc1=new Scanner(System.in);
		System.out.println("enter the size of the array");
		int size=sc1.nextInt();
		arr1=new int[5];
		for (int i = 0; i < arr1.length; i++) {
			arr1[i]=sc1.nextInt();
			
		}
		System.out.println("array elements are ");
		for(int i = 0;i<arr1.length;i++){
			System.out.println(arr1[i]+" ");
		}
		System.out.println("sorted array");
	Arrays.sort(arr1);
	for(int i=0;i<arr1.length;i++){
		System.out.print(arr1[i]+" ");
	}
	System.out.println("---------------------------------");
	}
}
