package arrays;

public class Java {
String inkColor;
 void pen(String inkColor)
{
	this.inkColor=inkColor;
}

public String toString()
{
	return inkColor +"pen";
}
}