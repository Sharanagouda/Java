package arrays;

import java.util.ArrayList;
import java.util.Iterator;



public class Student {
	int rollno;
	String name;
	int age;
	
public Student(int i, String string, int j) {
	
		this.rollno=i;
		this.name=string;
		this.age=j;
	
	}

public static void main(String[] args) {
	
	ArrayList<String> al=new ArrayList<String>();
	al.add("abhi");
	al.add("llash");
	al.add("Prashant");
	
	
	ArrayList<String> at=new ArrayList<String>();
     at.add("Sharanu");
     at.add("Praveen");
     
     al.addAll(at);
    Iterator itr=al.iterator();
 	while(itr.hasNext()){
 		System.out.print(itr.next()+" ");
 		
 	}
}
}
