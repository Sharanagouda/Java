package arrays;

import java.util.ArrayList;
import java.util.Scanner;

public class Missing_Number {

	public static void main(String[] args) {
		ArrayList<Integer> ar = new ArrayList<Integer>();

		int a[] = { 1, 2, 4,8,11,15,17 }; 				// a[0]=1 and so on a[6]=17
		int b = a[0]; 							// copy a to b
		for (int i = 0; i < a.length; i++) { 		// a.length=10

			if (b == a[i])						 // b=a[0]=1, b=a[1]=2
			{
				b++;								 // b=2,b=3!=a[2]

			} else {
				ar.add(b); 								// ar=3
				i--;									 // i=2
				b++; 									// b=4
			}
		}

		for (int r : ar) {

			System.out.print(r + ",");
		}
	}

}
