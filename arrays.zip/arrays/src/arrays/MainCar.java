package arrays;

import java.util.Scanner;

public class MainCar {
	static int bmwcount = 0;
	static int audicount = 0;
	static int maruticount = 0;
	static int nanocount = 0;


	public static void main(String[] args) {
		System.out.println("**************************************************");
		System.out.println("WELCOME to JSpiders car Parking system ");
	
		Car[] Parking = new Car[20];
		Parking[0] = Car("audi");
		
		Car[] park = new Car[5];
		CarParking Car1 = new CarParking();
		Car1.TotalCapacity(Parking);
		Car1.CarParking(Parking);
		Car1.displayCars(Parking);

		for (int j = 5; j <= 10; j++) {

			audicount++;
			System.out.println("audi car:" + audicount);
		}

		Car[] park1 = new Car[5];
		for (int k = 1; k <= 5; k++) {

			bmwcount++;
			System.out.println("BMW car:" + bmwcount);}

			Car[] park11 = new Car[2];
			for (int l = 1; l <= 2; l++) {

				nanocount++;
				System.out.println("NANO car:" + nanocount);}

				Car[] park111 = new Car[3];
				for (int m = 1; m <= 3; m++) {

					maruticount++;
					System.out.println("MARUTI car:" +maruticount);}
				
				
					System.out.println("**********************************************");
					Scanner sc1=new Scanner(System.in);
					System.out.println("Enter slot number");
					int slotno=sc1.nextInt();
					
					switch (slotno)
					{
					case 8:System.out.println("8 slot is conformed");
							break;
					case 12:System.out.println("12 slot is conformed");
							break;
					case 13:System.out.println("13 slot is conformed");
							break;
					case 17:System.out.println("17 slot is conformed");
							break;
					case 20:System.out.println("20 slot is conformed");
							break;
							default:System.out.println("no more slot to park");
					}
	
		
				
				}
	

	private static Car Car(String string) {
		// TODO Auto-generated method stub
		return null;
	}


	

}
