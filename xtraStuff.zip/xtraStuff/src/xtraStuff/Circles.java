package xtraStuff;

import java.awt.*;
import java.applet.*;
import java.util.*;
public class Circles extends Applet
{
public void paint(Graphics g)
{
Random rg = new Random();
for (int i=1; i<=3; i++)
{
int r = rg.nextInt(255);
int gr = rg.nextInt(255);
int b = rg.nextInt(255);
Color c = new Color(r,gr,b);
g.setColor(c);
g.drawOval(100+i*5,100+i*5,100-i*10,100-i*10);
}
}
}