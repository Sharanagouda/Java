package xtraStuff;

public class MainClass {
    static int i = 1;
    
    static
    {
        i = i-- + --i;    // i=0+-1=-1
    }
 
    {
        i = i++ - ++i;    //i=0-1=-1
    }
 
    int methodOfTest()
    {
        return i + i - i * i / i;     //-1+(-1)-(-1)*-1/-1;    i=-2
    }
 
    public static void main(String[] args)
    {
        System.out.println(new MainClass().methodOfTest());
    }

}
