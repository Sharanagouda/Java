package xtraStuff;

public class TryCatch {

	public static void main(String[] args) {
		try {
		
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("load success");

		} catch (ClassNotFoundException e) {
			System.out.println("Loading failed");

		}

	}
}
