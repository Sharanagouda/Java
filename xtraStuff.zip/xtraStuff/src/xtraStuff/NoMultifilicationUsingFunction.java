package xtraStuff;

public class NoMultifilicationUsingFunction {

	public static void main(String[] args) {
		f1(2, 4);
		f2(2,45.05);
	}

	static void f1(int a, int b) {

		System.out.println(a * b);
	}
	static void f2(int a, double b){
		System.out.println(a * b);
	 
}
}