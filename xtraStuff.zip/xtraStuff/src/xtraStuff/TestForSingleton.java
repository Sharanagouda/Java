package xtraStuff;

public class TestForSingleton {
	private static TestForSingleton t;
	private TestForSingleton(){
		System.out.println("SingleTon Project");
	}

	private static TestForSingleton getInstance(){
		
		if(t==null){
			synchronized (TestForSingleton.class) {
				if(t==null){
					t=new TestForSingleton();
				}
				
			}
		}
		return t;
		
	}
	void diplay(){
		System.out.println("Display method...");
	}
	public static void main(String[] args) {
		TestForSingleton t1=new TestForSingleton();
		t1.diplay();
	}
}
