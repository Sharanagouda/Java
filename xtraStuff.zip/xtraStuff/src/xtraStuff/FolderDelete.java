package xtraStuff;

import java.io.File;

public class FolderDelete {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		FolderDelete f=new FolderDelete();
		f.DeleteFullFolder();
		
				
	}

	private void DeleteFullFolder() {
		String pathname="G:\\software\\Adobe Photoshop CS5 Extended Edition\\Adobe Photoshop CS6 13.0.1 Final  Multilanguage (cracked dll)";
		File folder=new File(pathname);
		try{
			if(folder.exists()){
				if(folder.isDirectory()){
					File[] list= folder.listFiles();
					for(File file:list){
						file.delete();
					}
					folder.delete();
					System.out.println("Folder "+folder.getName()+"was deleted");
				}
			}else{
				System.out.println("Folder: "+folder.getName()+"Is not exist in the directory");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
