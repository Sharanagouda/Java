package xtraStuff;

public class Abstract{
	
	int m;
	double n;
	

	
	public Abstract(int i){
	m=i;
	}
	public Abstract(double d){
		n=d;
	}{
	System.out.println(m);
	System.out.println(n);
	}
public static void main(String[] args) {
	Abstract a=new Abstract(500);
	Abstract b=new Abstract(50.05);
	System.out.println(a.m+" ");
	System.out.println(b.n+" ");
}	
}