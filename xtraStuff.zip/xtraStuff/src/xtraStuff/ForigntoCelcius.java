package xtraStuff;

import java.util.Scanner;

public class ForigntoCelcius {
static float frn,clc;


	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER THE FARHAN HEAT DEGREES.....");
		frn=sc.nextFloat();
		
		clc=(float) (((frn-32)*5.0)/9.0);
	System.out.println("Celsun DEGREES:  " +clc);
	System.out.println();
	
	System.out.println("ENTER THE CELCIUS HEAT DEGREE...");
	clc=sc.nextFloat();
	frn=(float) (((9.0*clc)/5.0)+32);
	
	System.out.println("Foriegn heat degree is:  "+frn);
	
		
	}

}
