package xtraStuff;

public class ExampleFive {
	public static void main(String[] args) {
        final int i = 22;
        byte b = i;
        System.out.println(i + ", " + b);
    }
}
