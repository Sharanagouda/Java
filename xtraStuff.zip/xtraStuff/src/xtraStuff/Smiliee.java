package xtraStuff;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
/*<applet code="smile.class" height=200 width=200></applet>*/;
public class Smiliee extends Applet
{
public void paint(Graphics g)
{
g.drawOval(250,250,300,300);
g.drawOval(310,320,30,30);
g.drawOval(440,320,30,30);
g.drawLine(390,350,390,390);
g.drawArc(330,400,140,90,0,-180);
}
}
