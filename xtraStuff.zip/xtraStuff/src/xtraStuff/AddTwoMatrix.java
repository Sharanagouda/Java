package xtraStuff;
import java.io.*;
class addmatrix
{

static void add()
{
int a[][], b[][], c[][];
a = new int[2][2];
b = new int[2][2];
c = new int[2][2];
DataInputStream dts=new DataInputStream(System.in);
try
{
System.out.println("enter first matrix 2*2 order :");
for(int i=0;i<2;i++)
{
for(int j=0;j<2;j++)
{
a[i][j]=Integer.parseInt(dts.readLine());
}
}
System.out.println("enter second matrix 2*2 order :");
for(int i=0;i<2;i++)
{
for(int j=0;j<2;j++)
{
b[i][j]=Integer.parseInt(dts.readLine());
}
}
for(int i=0;i<2;i++)
{
for(int j=0;j<2;j++)
{
c[i][j]=a[i][j]+b[i][j];
}
}
for(int i=0;i<2;i++)
{
for(int j=0;j<2;j++)
{
System.out.print(c[i][j]+" ");
}
System.out.println("\t");
}
}
catch(Exception x)
{
System.out.println("error");
}
}
public static void main(String arg[])
{
add();
}
}