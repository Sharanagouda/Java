package xtraStuff;

import java.util.jar.JarEntry;

public enum enums {
	;

	public static void hasMoreElements() {
		// TODO Auto-generated method stub
		
	}

	public static JarEntry nextElement() {
		// TODO Auto-generated method stub
		return null;
	}

	

	


}
