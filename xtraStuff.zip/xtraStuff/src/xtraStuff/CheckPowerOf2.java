package xtraStuff;

import java.util.Scanner;

public class CheckPowerOf2 {

	public static void main(String[] args) {
		int count = 0, num, n = 0, k = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number to Check");
		num = sc.nextInt();
		System.out.println(n);
while(((num!=2)&& num%2==0)||num==1){
	n=num/2;

}
return;


	}
	
}
