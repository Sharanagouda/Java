//Patterns of

package jspider_labtest;

public class Pattern {

	public static void main(String[] args) {
int line=5;
int space=4;
int time=1;

while(line>0){
	for(int i=1;i<=space;i++)
	{
		
	}
	for(int j=1;j<=time;j++)
	{
		System.out.print(j);
		System.out.println( );
		line--;
		time=time+1;
		space--;
		j=j+2;
	}
}
	}

}
