package jspider_labtest;

import java.util.Random;

public class Answer_pseudo {

	public static void main(String[] args) {
		//System.out.println("first argument is: "+args[0]);
		int n=15;
		String name="Rahul ";
		System.out.println("Generating random integers in range 6 to 15");
		Random randomGenerator = new Random();
		for (int i = 1; i <= 8; i++) {
			int GeneratedNumber = randomGenerator.nextInt(n);
			if(GeneratedNumber>6)
			System.out.println(name + GeneratedNumber);
		}
	}

}
