//Program To print 1 to 20 number with Even & Odd &Divisible by 3 

package jspider_labtest;

public class Number1to20 {

	public static void main(String[] args)
	{
	int num1=20;
	int even = 0,odd = 0,num;
	for(int i=1;i<=num1;i++)
	{
		num=num1%2;
		if(num==0)
		    even++;
		else
			odd++;
		
	}
	System.out.println("Total Even numbers "+even);
	System.out.println("Total Odd numbers "+odd);
	}

}
