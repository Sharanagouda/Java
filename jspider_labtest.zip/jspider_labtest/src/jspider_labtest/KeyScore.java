package jspider_labtest;

public class KeyScore {
	static int str = 0;

	public static void main(String[] args) {
		getScore(str);
	}
	public static int getScore(int str) {
		int res = 0;
		String s1 = "Brocolli is good(5) to eat. My brother likes(4) to eat good(5) brocolli, but not(-4) my mother.";
		String[] s = s1.split(" ");
		char[] c = { '-', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
		for (int i = 0; i < s.length; i++) {
			// System.out.println("for i"+i+".."+s[i]);
			// Spilt the sentence into words
			for (int j = 0; j < s[i].length(); j++) {
				// word length
				for (int m = 0; m < c.length; m++) {
					// This loop is to search the integer from word
					if ((s[i].charAt(j) == c[m]) && (s[i].charAt(j - 1) != '-')) {
						// this above if condition to find -ve sign
						if (s[i].charAt(j) == '-') {
							// System.out.println(res);
							res = res - (s[i].charAt(j + 1) - '0');
							// this is subtract -ve integers
						} else {
							res = res + (s[i].charAt(j) - '0');
							// System.out.println("result is:"+res);
						}
					}
				}
			}
		}
		System.out.println("The KeyScore Results are");
		System.out.println("KeyScore is for 1st = " + res);
		return res;

	}
}
