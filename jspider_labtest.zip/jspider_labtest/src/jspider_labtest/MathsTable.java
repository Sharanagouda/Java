//Mathematical Table
package jspider_labtest;

public class MathsTable {

	public static void main(String[] args) {
	int a=1,b=2,c=3,ans1,ans2,ans3,ans4,ans5,ans6,ans7,ans8,ans9;
	{
		ans1=a*a;
		ans2=a*b;
		ans3=a*c;
		
		ans4=b*a;
		ans5=b*b;
		ans6=b*c;
		
		ans7=c*a;
		ans8=c*b;
		ans9=c*c;
	}
      System.out.println(ans1+"     "+ans2+"    "+ans3);
      System.out.println(+ans4+"     "+ans5+"    "+ans6);
      System.out.println(+ans7+"     "+ans8+"    "+ans9);
      
	}

}
