package jspider_labtest;

public class CircleSquaireRectangleTrinangle {

	public static void main(String[] args) {
		System.out.println(GetAreaOfCircle(4.5));
		System.out.println(GetAreaOfSquaire(6.2));
		System.out.println(GetAreaofRectangle(4, 4.5));
		System.out.println(GetAreaOfTriangle(6, 2.8));

	}
static double GetAreaOfCircle(double rad){
	final double PI=3.142;
	double area=PI*rad*rad;
	return area;
	
}
static double GetAreaOfSquaire(double len){
	double area=len*len;
	return area;
	
}
static double GetAreaofRectangle(double len,double width){
	double area=len+width;
	return area;
	
}
static double GetAreaOfTriangle(double base,double height){
	double area=base*height*1/2;
	return area;
	
}
}
