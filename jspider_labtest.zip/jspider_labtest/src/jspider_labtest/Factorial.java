// factorial of given number
package jspider_labtest;

public class Factorial
{

	static int fact(int num)
	{
		int fact = 1;
		for (int i = 1; i <= num; i++) 
		{
			fact = fact * i;
		}
		return fact;
	}

	public static void main(String[] args) {
		int result = fact(6);
		System.out.println("Factorial result : " + result);

	}

}
