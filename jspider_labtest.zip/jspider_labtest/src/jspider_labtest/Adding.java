package jspider_labtest;

public class Adding {

	public static void main(String[] args) {
	int a=18,b=6;
	{
		a=a^b;
		
		
		
		
		
	}
	System.out.println("sum is"+a);
	
	}

}
