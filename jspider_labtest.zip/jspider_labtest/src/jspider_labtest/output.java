package jspider_labtest;

import java.awt.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class output {
	public static void main(String[] args) {
		Object i=new ArrayList().iterator();
		System.out.println((i instanceof List)+" ,");
		System.out.println((i instanceof Iterator)+ ", ");
		System.out.println((i instanceof ListIterator)+",");
		double d=Math.round(2.5+Math.random());
		System.out.println(d );
		
	}
	public void foo(){
		assert false;
		assert false;
		
	}
public void bar(){
	while(true){
		assert false;
	break;
	}assert false;
}
}
