package jspider_labtest;
import java.io.*;
public class Test {

	 
//	/* Name of the class has to be 'Main' only if the class is public. */
//	class Test
//	{
		public static void main (String[] args) throws java.lang.Exception
		{
		    int a=0,b=1,c,i=0;
			BufferedReader r = new BufferedReader (new InputStreamReader (System.in));
			String s;
			int n=Integer.parseInt(r.readLine());
			while(i<n){
			   
			
			c=a+b;
			a=b;
			b=c;
			    int ar[]=new int[n];
			    for(int j=0;j<n;j++){
			    	ar[i]=Integer.parseInt(r.readLine());
			        System.out.println(ar[i]);
			    }
			}
			
//			while (!(s=r.readLine()).startsWith('2')) System.out.println(s);
		}

		private static int Integer.parseInt(String readLine) {
			// TODO Auto-generated method stub
			return 0;
		}
		
	}
