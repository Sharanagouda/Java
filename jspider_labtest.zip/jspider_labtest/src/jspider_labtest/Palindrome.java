package jspider_labtest;

import java.util.Scanner;

public class Palindrome {
public static void main(String[] args) {
	String Original,reverse="";
	Scanner scn=new Scanner(System.in);
	System.out.println("Enter a String to check if it is a palindrom");
	Original=scn.nextLine();
	int length =Original.length();
	for (int i =length-1; i >=0; i--) {
		reverse=reverse+Original.charAt(i);
		
	}
	if(Original.equals(reverse)){
		System.out.println("Entered String is Palidrome");
	}
	else{
		System.out.println("Entered String is not a Palindrome");
	}
	scn.close();
}
}
