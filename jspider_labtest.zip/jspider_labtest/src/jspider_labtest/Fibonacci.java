package jspider_labtest;

public class Fibonacci {
public static void main(String[] args) {
	int first=0,second=1;
	int next=1;
	System.out.print(first+","+second);
	int maxvalue=100;
while(first+second<=maxvalue){
	next=first+second;
	System.out.print(","+next);
	first=second;
second=next;}
}
}
