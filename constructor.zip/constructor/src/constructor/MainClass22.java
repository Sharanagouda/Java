package constructor;

public class MainClass22 {

	public static void main(String[] args) {
		System.out.println("------------------------------------");
		Sample22 s1 = new Sample22();
		Sample22 s2 = new Sample22();
		Sample22 s3 = new Sample22();
		Sample22 s4 = new Sample22();
		System.out.println("Total object:" + Sample22.objCount);
		System.out.println("--------------------------------------");

	}

}
