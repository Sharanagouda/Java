package constructor;

public class Book {
	int totalPages;

	Book(int totalPages) {
		System.out.println("Creating Book of " + totalPages);
		this.totalPages = totalPages;
	}

	void OpenBook() {
		System.out.println("Opening Book.............");

	}

	void TurnPage() {
		System.out.println("Turning Pages............");
	}

	void CloseBook() {
		System.out.println("ClosingBook..................");

	}

}
