package constructor;

public class Sample31 {
	int k;

	Sample31() {
		System.out.println("Running Constructor Body");
		k = 13;
	}
}
