package constructor;

public class MainClass31 {

	public static void main(String[] args) {
		System.out.println("----------------------------------");
		Sample31 obj1 = new Sample31();
		System.out.println("k value of 1st object:" + obj1.k);
		System.out.println("-----------------------------------");
		Sample31 obj2 = new Sample31();
		System.out.println("k value of 2nd objects:" + obj2.k);
		System.out.println("-------------------------------------");
	}

}
