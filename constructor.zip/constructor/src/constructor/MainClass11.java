package constructor;

public class MainClass11 {

	public static void main(String[] args) {
		
			System.out.println("----------------------------------");
			Sample11 s1 = new Sample11();
			Sample11 s2 = new Sample11();
			System.out.println("------------------------------------");

	}

}
