package constructor;

public class Mainclass2 {

	public static void main(String[] args) {
		System.out.println("----------------------------");
		Demo2 obj2 = new Demo2();
		System.out.println("d value:" + obj2.d);
		obj2.test();
		System.out.println("------------------------------");
		System.out.println("k value : " + Demo2.ref1.k);
		Demo2.ref1.disp();

		System.out.println("------------------------------");
	}

}
