package constructor;

public class Sample8
{
static int k=12;
int i=24;
//instance or non static context
void print()
{
	System.out.println("Running print() method");
	System.out.println("k value:"+k);
	System.out.println("i value :"+this.i);
}
//Static  context
static void disp()
{
	System.out.println("Running disp() method");
	System.out.println("k value:"+k);
	Sample8 ref1=new Sample8();
	System.out.println("i value:"+ref1.i);
}
}
