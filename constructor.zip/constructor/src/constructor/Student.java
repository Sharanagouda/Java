package constructor;

public class Student
{
	int id;
	Student (int arg1)
	{System.out.println("Creating intstance ");
	this.id=arg1;
	//this is an instance and id is an argument 
	}

}
