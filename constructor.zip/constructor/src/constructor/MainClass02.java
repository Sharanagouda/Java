package constructor;

public class MainClass02 {

	public static void main(String[] args) {
	System.out.println("main method started---------- ");
	System.out.println("i value :"+new Sample02().i);
	new Sample02().i=12;
	System.out.println("i value :"+new Sample02().i);
	//3differernt objects are ended
	System.out.println("main method ended--------");
	
	}

}
