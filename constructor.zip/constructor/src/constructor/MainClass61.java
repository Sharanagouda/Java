package constructor;

public class MainClass61 {

	public static void main(String[] args) {
		System.out.println("--------------------------------------");
		Sample61 ref1 = new Sample61(23,5.6);
		System.out.println("k value :" + ref1.k);
		System.out.println("d value :" + ref1.d);
		System.out.println("--------------------------------------");

	}

}
