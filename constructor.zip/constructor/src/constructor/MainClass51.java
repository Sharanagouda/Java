package constructor;

public class MainClass51 {

	public static void main(String[] args) {
		System.out.println("-----------------------------");
		Sample51 obj1 = new Sample51(5633);
		System.out.println("k value :" + obj1.id);
		System.out.println("----------------------------");
		Sample51 obj2 = new Sample51(378);
		System.out.println("k value :" + obj2.id);
		System.out.println("---------------------------");
	}

}
