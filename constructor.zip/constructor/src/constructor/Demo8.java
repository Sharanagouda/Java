package constructor;

public class Demo8 {

	public static void main(String[] args)
	{
		
System.out.println("........................");
Sample8 obj1=new Sample8();
obj1.print();
Sample8.disp();
System.out.println(".................");

	}
}
