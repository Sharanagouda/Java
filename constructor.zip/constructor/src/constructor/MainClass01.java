package constructor;

public class MainClass01 {
	public static void main(String[] args) {
		System.out.println("-----------------------------------------");
		System.out.println("j value :" + new Sample01());
		new Sample01().test();
		System.out.println("--------------------------------------");
	}
}
