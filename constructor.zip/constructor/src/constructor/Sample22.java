package constructor;

public class Sample22 {
static int objCount;
Sample22()
{
	System.out.println("running Constructor Body");
	objCount++;
}
}
