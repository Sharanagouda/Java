package constructor;

public class Writer {

	String name;

	Writer(String name) {

		this.name = name;
		System.out.println(this.name + " is Ready");
	}

	void editStory(Pen p1, Book b1) {
		b1.OpenBook();
		p1.write();
		b1.TurnPage();
		p1.write();
		b1.CloseBook();

	}
}
