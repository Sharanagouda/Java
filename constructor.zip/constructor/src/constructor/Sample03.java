package constructor;

public class Sample03 {
	int k;
	double d;

	// Overload constructor
	Sample03(int arg1) {
		System.out.println("Running int arg1 Constructors");
		k = arg1;
	}

	Sample03(double arg2) {
		System.out.println("Running double arg2 Constructor");
		d = arg2;
	}

	Sample03(int arg1, double arg2) {
		System.out.println("Running int and double Constructor");
		k = arg1;
		d = arg2;
	}
}
