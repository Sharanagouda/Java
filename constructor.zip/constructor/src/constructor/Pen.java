package constructor;

public class Pen {
	String inkColor;

	Pen(String inkColor) {
		System.out.println("Creating " + inkColor + "Pen");
		this.inkColor = inkColor;
	}

	void write() {
		System.out.println("writing...........");
	}
}
