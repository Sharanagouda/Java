package constructor;

public class Sample01 {
int j=12;
void test()
{
	System.out.println("Running instance method");
}
}//exple->to refer instance or non static member or Sample class
