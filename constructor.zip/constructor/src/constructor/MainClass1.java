package constructor;

public class MainClass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("........................................");
		Demo1 obj1 = new Demo1();
		System.out.println(" d value : " + obj1.d);
		obj1.test1();

		System.out.println(" k value : " + obj1.ref1.k);
		obj1.ref1.disp();
		System.out.println("...........................................");

	}

}
