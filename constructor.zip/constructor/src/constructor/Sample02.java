package constructor;

public class Sample02 {
int i;
}
