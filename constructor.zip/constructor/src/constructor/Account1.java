package constructor;

public class Account1 {

	public static void main(String[] args) {
		System.out.println("----------------------------------");
		Accout a1 = new Accout(10000.00);
		a1.viewBalance();
		a1.withdrawal(2000.00);
		a1.viewBalance();
		a1.deposit(4000.00);
		a1.viewBalance();
		System.out.println("------------------------------------");

	}

}
