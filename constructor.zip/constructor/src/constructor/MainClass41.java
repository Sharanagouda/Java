package constructor;

public class MainClass41 {

	public static void main(String[] args) {
		System.out.println("------------------------------------------");
		Sample41 obj1=new Sample41(62);
		System.out.println("k value of object:"+obj1.k);
		System.out.println("------------------------------------------");
		Sample41 obj2=new Sample41(16);
		System.out.println("k value of object:"+obj2.k);
		System.out.println("-------------------------------------------");
	}

}
