package constructor;

public class Sample5 {
	int k;
	double d;

	// overloaded constructors
	Sample5(int arg1) {
		System.out.println("Runnig int arg constructor Body");
		k = arg1;
	}

	Sample5(double arg1) {
		System.out.println("Running double arg1 constructors");
		d = arg1;
	}

	Sample5(int arg1, double arg2) {
		System.out.println("running int arg,double arg1 constructors");
		k = arg1;
		d = arg2;
	}
}
