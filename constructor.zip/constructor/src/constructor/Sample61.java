package constructor;

public class Sample61 {
	int k;
	double d;

	// Overloading Constructor
	Sample61(int arg1) {
		System.out.println("Running int arg Constructor");
		k = arg1;

	}

	Sample61(double arg2) {
		this(51);
		// call int arg Constructor of this class
		System.out.println("Running double args Constructor");
		d = arg2;
	}

	Sample61(int arg1, double arg2) {
		System.out.println("Running int args, double args constructors");
		k = arg1;
		d = arg2;
	}
}
