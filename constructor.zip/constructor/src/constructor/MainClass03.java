package constructor;

public class MainClass03 {

	public static void main(String[] args) {
		System.out.println("-----------------------------------");
		Sample03 ref1=new Sample03(12);
		System.out.println("k value:"+ref1.k);
		System.out.println("d value:"+ref1.d);
		
		Sample03 ref2=new Sample03(2.3);
		System.out.println("k value:"+ref2.k);
		System.out.println("d value:"+ref2.d);
		
		Sample03 ref3=new Sample03(12,26.3);
		System.out.println("k value:"+ref3.k);
		System.out.println("d value:"+ref3.d);
		System.out.println("-----------------------------------");
		

	}

}
