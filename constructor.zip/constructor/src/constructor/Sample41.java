package constructor;

public class Sample41 {
int k=12;
Sample41(int arg)
{
	System.out.println("Running Constructor Body");
	k=arg;
}
}
