package constructor;

public class Sample1 {
	int k = 12;

	void disp() {
		System.out.println("Running disp() method");
	}
}
