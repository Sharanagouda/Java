package constructor;

public class TestStudent {

	public static void main(String[] args) {
	System.out.println("................................");
	Student s1=new Student(654133);
	System.out.println("Student id is :"+s1.id);
	System.out.println("...............................");
	}

}
