package constructor;

public class Demo1 {
	double d = 23.26;
	Sample1 ref1 = new Sample1();

	// instance object of Sample1 type
	void test1() {
		System.out.println("Running test1() method");
	}
}
