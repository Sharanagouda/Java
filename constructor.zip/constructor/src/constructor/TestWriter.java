package constructor;

public class TestWriter {

	public static void main(String[] args) {

		System.out.println(".................................");
		Pen CelloPen = new Pen("Red");
		Book Classmate = new Book(50);
		Writer Storywriter = new Writer("Chethan Bhaghat");
		Storywriter.editStory(CelloPen, Classmate);
		System.out.println("...................................");

	}

}
