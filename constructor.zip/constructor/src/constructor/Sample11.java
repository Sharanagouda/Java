package constructor;

public class Sample11 {
	Sample11() {
		System.out.println("Running Constuctor body");

	}

}
