package constructor;

public class Demo2 {
	double d = 23.12;
	static Sample2 ref1 = new Sample2();

	// Static object of Sample type
	void test() {
		System.out.println("Running test() of Demo2");
	}
}
