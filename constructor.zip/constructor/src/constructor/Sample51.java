package constructor;

public class Sample51 {
	final int id;

	Sample51(int arg1) {
		System.out.println("Running Sample51 Constructor Body");
		id = arg1;
	}
}
