
import com.cete.dynamicpdf.Document;
import com.cete.dynamicpdf.imaging.TiffFile;

public class TiffToPDF {

    /** Creates a new instance of TiffToPDF */
    public TiffToPDF() {
    }

    public static void main(String[] args) throws Exception {
        // Create a TiffFile object from the TIFF image
        TiffFile tiffFile = new TiffFile("images/fw9_11.tif");

        // Create a document object from the file
        Document document = tiffFile.getDocument();
        document.setCreator("TiffToPDF.aspx");
        document.setAuthor("ceTe Software");
        document.setTitle("TiffToPDF");

        // Save the PDF document
        document.draw("tiff.pdf");
    }
}
