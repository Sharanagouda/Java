import com.cete.dynamicpdf.Certificate;
import com.cete.dynamicpdf.Document;
import com.cete.dynamicpdf.Page;
import com.cete.dynamicpdf.pageelements.forms.Signature;
import java.io.FileNotFoundException;

public class Sign {
    public static void main(String args[]) {
        // Create a PDF Document and Add a Page
        Document document = new Document();
        document.setCreator("DigitalSignatures.aspx");
	    document.setAuthor("ceTe Software");
	    document.setTitle("DigitalSignatures");
        Page page = new Page();
        document.getPages().add(page);
        
        // Add signature field to the page
        Signature signature = new Signature("SigField", 10, 10, 250, 100);
        page.getElements().add(signature);
        
		Certificate certificate = null;

        // Create a Certificate from the file
		try {
	        certificate = new Certificate("data/JohnDoe.pfx", "dynamicpdf");			
		}
		catch (FileNotFoundException ex) {
			System.out.println("File doesn't exist");
		}
        
        // Sign the document refering the sign field
        document.sign("SigField", certificate);
        
        //Draw the output to the document
        document.draw("DigitalSignature.pdf");
    }
}
