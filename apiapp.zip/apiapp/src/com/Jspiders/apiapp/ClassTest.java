package com.Jspiders.apiapp;

import com.cete.dynamicpdf.*;
import com.cete.dynamicpdf.pageelements.Label;

public class ClassTest {

	public static void main(String args[]) {
		// Create a document and set it's properties
		Document objDocument = new Document();
		objDocument.setCreator("HelloWorldTaggedPdf.java");
		objDocument.setAuthor("ceTe Software");
		objDocument.setTitle("Hello World");

		// Specify document as tagged PDF
		objDocument.setTag(new TagOptions());

		// Create a page to add to the document
		Page objPage = new Page(PageSize.LETTER, PageOrientation.PORTRAIT, 54.0f);

		// Create a Label to add to the page
		String strText = "Hello World...\nFrom DynamicPDF Generator " + "for Java\nDynamicPDF.com";
		Label objLabel = new Label(strText, 0, 0, 504, 100, Font.getHelvetica(), 18, TextAlign.CENTER);

		// Add label to page
		objPage.getElements().add(objLabel);

		// Add page to document
		objDocument.getPages().add(objPage);

		// Outputs the document to file
		objDocument.draw("HelloWorldTaggedPdf.pdf");
	}

}
