package thread;

public class TestSynchronization {

	

		public static void main(String[]args) {
			Synchronization obj=new Synchronization(1);
			Thread t1=new Thread(obj);
			Thread t2=new Thread(obj);
			
			t1.setName("First Person");
			t2.setName("Second Person");
			t1.start();
			t2.start();
			
			
			// TODO Auto-generated method stub

		}

	}