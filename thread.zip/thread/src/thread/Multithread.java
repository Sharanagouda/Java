package thread;

public class Multithread implements Runnable
{
	String str;
	Multithread(String str){
		this.str=str;
		
	}

	public static void main(String[] args) {
		Multithread obj1=new Multithread("Cut the tickets:");
		Multithread obj2=new Multithread("Show the seats : ");
		
		// TODO Auto-generated method stub
Thread t1=new Thread(obj1);
Thread t2=new Thread(obj2);
t1.start();
t2.start();

	}

	@Override
	public void run() {
		for (int i = 1; i <=4; i++) {
			System.out.println(str+" "+i);
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		System.out.println("Over");// TODO Auto-generated method stub
		
	}

}
