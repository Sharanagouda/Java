package thread;

public class Work {

public static void main(String[] adfs){
	System.out.println("jshkfjsgs");

}
}
