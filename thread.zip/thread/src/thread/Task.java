package thread;

public class Task implements Runnable   {
public void run(){
	task1();
	task2();
	task3();
	
}
void task1(){
	System.out.println("task1 is tunning");
	
}
void task2(){
	System.out.println("task2 is running");
	
}
void task3(){
	System.out.println("task3 is running");
}
	public static void main(String[] args) {
		Task obj=new Task();
		Thread t=new Thread(obj);
		t.start();
		
		
		// TODO Auto-generated method stub

	}

}
