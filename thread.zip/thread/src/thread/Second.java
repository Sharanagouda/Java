package thread;

public class Second implements Runnable {

	public static void main(String[] args) {
Second sec=new Second();
Thread th=new Thread(sec);
System.out.println("Thread ID= "+th.getId());
System.out.println("Thread Name= "+th.getName());
System.out.println("Thread Preority= "+th.getPriority());
System.out.println(th.hashCode());

System.out.print("after modifying/......\n\n\n\n");

th.setName("MyThreadaaa");
th.setPriority(6);
System.out.println("Thread ID= "+th.getId());
System.out.println("Thread Name= "+th.getName());
System.out.println("Thread Preority= "+th.getPriority());
System.out.println(th.hashCode());


	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
