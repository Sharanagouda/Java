package thread;

public class CommonResorce {
	synchronized void resorce(){
		Thread th=Thread.currentThread();
		System.out.println(th.getName());
		System.out.println("Printing numbers from 1 to 25");
		for(int i=1;i<=25;i++){
			System.out.println(i);
			try{
				Thread.sleep(500);
				
			}catch(InterruptedException exp){
				exp.printStackTrace();
			}
		}
	
	}

}
