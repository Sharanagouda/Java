package thread;

public class First implements Runnable {

	@Override
	public void run() {
		System.out.println("Printing  numbers from 1 to 30");
		for (int i = 0; i <= 4; i++) {
			System.out.println(i = +i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException exp) {
				exp.printStackTrace();
			}
		}

	}

	public void run2() {
		System.out.println("printing again numbers from 30 to 40");
		for (int j = 30; j <= 33; j++) {
			System.out.println(j);
			try {
				Thread.sleep(2500);
			} catch (InterruptedException exp) {
				exp.printStackTrace();

			}
		}
	}

	public static void main(String[] args) {
		First one = new First();

		Thread th1 = new Thread(one);
		th1.start();
		System.out.println("the number reaches to max number");
		
		First two=new First();
		Thread th2 = new Thread(one);
		
		th2.start();
		System.out.println("ohhhh..again started see..up");

	}
}
