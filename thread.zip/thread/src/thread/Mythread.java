package thread;

import java.io.IOException;

public class Mythread extends Thread
{
	boolean stop=false;
	public void run(){
		for (int i = 1; i <=10000000; i++) {
			System.out.println(i);
			if(stop)return;
			
		}
	}
class Demo{
	
}
	public static void main(String[] args) throws IOException {
		Mythread obj=new Mythread();
		Thread t=new Thread(obj);
		t.start();
		System.in.read();
		obj.stop=true;
		
		// TODO Auto-generated method stub

	}

}
