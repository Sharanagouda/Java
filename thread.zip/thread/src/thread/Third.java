package thread;
////////////////////to delete file from directory....just give directory path of file
import java.io.File;
import java.io.IOException;

public class Third extends Thread {

	public static void main(String[] args) {
		
	
	System.out.println("------------------------------------------------------------------");
	File f1=new File("G:\\Notes\\02-corejava_2.pdf");
	try{
		f1.createNewFile();
		//Creating only empty  
		System.out.println(f1.exists());
		System.out.println("Write permission:"+f1.canWrite());
		f1.setWritable(false);
		System.out.println("write permission:"+f1.canWrite());
		f1.delete();
	
	}catch(IOException io){
		io.printStackTrace();
	}
	}
	
}
