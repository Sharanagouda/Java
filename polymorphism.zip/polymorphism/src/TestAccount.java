public class TestAccount {

	public static void main(String[] args) {
		System.out.println("------------------------------------------------");
		SavingsAccount sav1 = new SavingsAccount(10000.00);
		sav1.deposite(2000.00);
		sav1.viewBalance();
		sav1.Withdrawal(5000.00);
		sav1.viewBalance();
		System.out.println("------------------------------------------------");
		LoanAccount ln1 = new LoanAccount(50000.00);
		ln1.deposite(12000.00);
		ln1.viewBalance();
		ln1.withdrawal(5000.00);
		ln1.viewBalance();
		System.out.println("------------------------------------------------");

	}

}
