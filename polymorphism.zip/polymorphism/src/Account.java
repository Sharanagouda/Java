public class Account {
	void deposite(double amt) {
		System.out.println("code to implement deposite with Rs");

	}

	void withdrawal(double amt) {
		System.out.println("code to implement withdrawal");

	}

	void viewbalance() {
		System.out.println("code to implement view balance");

	}

}
