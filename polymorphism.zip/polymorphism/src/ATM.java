public class ATM {
	void transaction(Account arg1) {
		arg1.deposite(2000.00);
		arg1.viewbalance();
		arg1.withdrawal(5000.00);
		arg1.viewbalance();
	}
}
