public class SavingsAccount {
	double accBal;

	SavingsAccount(double initAmt) {
		System.out.println("Opening Savings account with Rs :" + initAmt);
		accBal =initAmt;
	}

	void deposite(double amt) {
		System.out.println("Depositing Rs : " + amt);
		accBal = accBal + amt;
	}
void Withdrawal(double amt)
{
	System.out.println("Withdrawing Rs : "+amt);
	accBal=accBal-amt;
}
	void viewBalance() {
		System.out.println("Current Balance Rs:" +accBal);
		
	}
}
