
public class MainATM {

	public static void main(String[] args) {
System.out.println("----------------------------------------------");
ATM atm1=new ATM();
SavingsAccount sav1 = new SavingsAccount(10000.00);
atm1.transaction(sav1);
System.out.println("---------------------------------------------");
LoanAccount ln1 = new LoanAccount(50000.00);
atm1.transaction(ln1);
System.out.println("-------------------------------------------");

	}

}
