package abstracrion;

public class MainTestAccount {

	public static void main(String[] args) {
		System.out.println("*******************************");
		ATMMachine atm1 = new ATMMachine();
		Account acc1 = Bank.getAccount('L');
		atm1.ATMMachine(acc1);
		System.out.println("********************************");
	}

}
