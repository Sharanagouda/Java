package abstracrion;

public interface Account {
	
		void deposite();
		void withdrawal();
		void ViewBalance();
		
	}
