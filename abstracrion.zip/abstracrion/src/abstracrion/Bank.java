package abstracrion;

public class Bank {
	static Account1 getAccount(char type) {
		Account1 a1 = null;
		if (type == 'S') {
			a1 = new SavingsAccount1(10000.00);

		} else if(type=='L'){
			a1 = new LoanAccount1(10000.00);
		}
		return a1;
	}
}
