package abstracrion;

public abstract class SavingsAccount1 implements Account {
	double accBal;

	SavingsAccount1(double initAmt) {
		System.out.println("Opening Savings account with Rs :" + initAmt);
		accBal =initAmt;
	}

	public void deposite(double amt) {
		System.out.println("Depositing Rs : " + amt);
		accBal = accBal + amt;
	}
public void Withdrawal(double amt)
{
	System.out.println("Withdrawing Rs : "+amt);
	accBal=accBal-amt;
}
	public void viewBalance() {
		System.out.println("Current Balance Rs:" +accBal);
		
	}
}
