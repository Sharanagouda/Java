package inbox;

public class Sample1 {
void disp()
{
	login.Demo1 ref1=new login.Demo1();
	System.out.println("x value :"+ref1.x);
}
}
