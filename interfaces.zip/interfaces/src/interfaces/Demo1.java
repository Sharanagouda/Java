package interfaces;

public interface Demo1 {
	int k = 327;   // we can also use this type public static int k=327; 

	void disp();    // for this public void disp()

}

class Sample1 implements Demo1 {
	public void disp() {
		System.out.println("Disp() is implemented in Sample1");
	}
}
