package interfaces;

public class MainDemo2 {

	public static void main(String[] args) {
		System.out.println("---------------------------------------------------");
		Demo2 ref1 = new Sample();
		ref1.disp(65);
		System.out.println("----------------------------------------------");
		Demo3 ref2 = new Sample();
		ref2.view(4.9);
		System.out.println("------------------------------------------------------");
	}

}
