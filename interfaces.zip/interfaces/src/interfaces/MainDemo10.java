package interfaces;

public class MainDemo10 {

	public static void main(String[] args) {
		System.out.println("************************************************");
		Demo10 ref1 = new Sample9();// change new Sample8(); and see the output
		ref1.disp();
		ref1.view();
		System.out.println("*************************************************");
	}

}

// for this you have to use or see Demo10,Sample8,Sample9 and MainDemo10