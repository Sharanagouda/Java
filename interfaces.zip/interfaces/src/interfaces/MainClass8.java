package interfaces;

public class MainClass8 {

	public static void main(String[] args) {
		System.out.println("****************************************************");
		Sample7 ref1 = new Sample7();
		ref1.disp();
		System.out.println("-----------------------------------------------------");
		Demo8 ref2 =new Sample7();
		ref2.disp();
		System.out.println("******************************************************");
	}

}
