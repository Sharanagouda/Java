package interfaces;

public class MainDemo1 {

	public static void main(String[] args) {
		System.out.println("----------------------------------------------------");
		Sample1 ref1 = new Sample1();
		ref1.disp();
		System.out.println("-----------------------------------------------------");
		Demo1 d1 = new Sample1();// Upcasting
		// interface reference points to object
		d1.disp();
		
		System.out.println("----------------------------------------------------");
	}

}
