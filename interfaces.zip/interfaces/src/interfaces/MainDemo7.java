package interfaces;

public class MainDemo7 {

	public static void main(String[] args) {
		System.out.println("------------------------------------------------------");
		Sample6 ref1 = new Sample6();
		ref1.test1();
		ref1.disp();
		System.out.println("---------------------------------------------------------");
		Sample5 ref2 = new Sample6();
		ref2.test1();
		System.out.println("--------------------------------------------------------");
		Demo7 ref3 = new Sample6();
		ref3.disp();
		System.out.println("---------------------------------------------------------");

	}

}
