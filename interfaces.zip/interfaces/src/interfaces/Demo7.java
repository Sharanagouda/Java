package interfaces;

public interface Demo7 {
	void disp();
}

class Sample5 {
	void test1() {
		System.out.println("Running test1() of Sample5 class");

	}
}

class Sample6 extends Sample5 implements Demo7 {
	public void disp() {
		System.out.println("Running disp() is implemented in Sample6");
	}
}
