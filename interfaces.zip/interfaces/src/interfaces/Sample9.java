package interfaces;

public class Sample9 implements Demo10 {
	public void disp() {
		System.out.println("disp() is implemented according to Sample9 class");

	}

	public void view() {
		System.out.println("view() is implemented according to Sample9 class");

	}
}

// for this you have to use or see Demo10,Sample8,Sample9 and MainDemo10
