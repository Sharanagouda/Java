package interfaces;

public class Sample8 implements Demo10 {
	public void disp() {
		System.out.println("disp() is implemented according to Sample8 class");
	}

	public void view() {
		System.out.println("view() is implemented according to Sample8 class");

	}
}

// for this you have to use or see Demo10,Sample8,Sample9 and MainDemo10