package interfaces;

public interface Run1 {
	default void start(Demo10 arg1)
	{
		void disp();
		void view();
		
	}
	
}
