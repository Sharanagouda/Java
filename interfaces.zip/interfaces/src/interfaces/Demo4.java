package interfaces;

public interface Demo4 {
	void disp(int arg1);
}

interface Demo5 {
	void view(double arg1);

}

class Sample3 implements Demo4, Demo5 {
	public void disp(int arg1) {
		System.out.println("disp(int) in defined in Sample3 class");
		System.out.println("arg1 value :" + arg1);
	}

	public void view(double arg1) {
		System.out.println("disp(double)is defined in Sample3 class");
		System.out.println("arg1 value:" + arg1);

	}
}
