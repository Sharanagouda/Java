package interfaces;

public interface Demo8 {
void disp();
}
interface Demo9
{
	void disp();
	
}
class Sample7 implements Demo8,Demo9
{
	public void disp()
	{
		System.out.println("Overriding disp()..................");
	}
}
