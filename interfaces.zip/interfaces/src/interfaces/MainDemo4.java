package interfaces;

public class MainDemo4 {

	public static void main(String[] args) {
		System.out.println("--------------------------------------------------------");
		Demo4 ref1 = new Sample3();
		ref1.disp(46);
		System.out.println("-------------------------------------------------------");
		Demo5 ref2 = new Sample3();
		ref2.view(7.8);
		System.out.println("-------------------------------------------------------");
	}

}
