package interfaces;

public interface Test {

}
