package interfaces;

public class MainRun1 {

	public static void main(String[] args) {
System.out.println("**************************************************");
Run1 r1=new Run1();
r1.start(Sample8());
r1.start(Sample9());
System.out.println("**************************************************");

	}

}
