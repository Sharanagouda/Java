package interfaces;

public interface Demo10 {
	void disp();

	void view();

}

// for this you have to use or see Demo10,Sample8,Sample9 and MainDemo10