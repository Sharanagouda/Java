package interfaces;

public interface Demo2 {
	void disp(int arg1);

}

interface Demo3 extends Demo2 {
	void view(double arg1);
}

class Sample implements Demo3 {
	public void disp(int arg1) {
		System.out.println("disp(int)defined in Sample2 class");
		System.out.println("arg1 value:" + arg1);
	}

	public void view(double arg1) {
		System.out.println("disp(double) defined in Sample2 class");
		System.out.println("arg1 value:" + arg1);

	}
}
