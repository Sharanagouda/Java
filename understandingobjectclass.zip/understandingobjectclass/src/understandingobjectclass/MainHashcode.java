package understandingobjectclass;

public class MainHashcode {

	public static void main(String[] args) {
		System.out.println("******************************************************************");
		Demo1 ref1 = new Demo1();
		int n1 = ref1.hashCode();
		System.out.println(n1);
		System.out.println("------------------------------------------------------------------");
		Demo1 ref2 = new Demo1();
		int n2 = ref2.hashCode();
		System.out.println(n2);
		System.out.println("*******************************************************************");
	}

}
