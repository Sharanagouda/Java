package understandingobjectclass;

public class Demo5 {

	public static void main(String[] args) {
		System.out.println("**************************************************************");
		Student s1 = new Student(64646, "Ramesh");
		Student s2 = new Student(68445, "Suresh");
		System.out.println(s1 == s2);
		boolean result = s1.equals(s2);
		// compare s1 with s2
		System.out.println(result);
		System.out.println("*****************************************************************");
	}

}
