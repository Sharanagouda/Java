package understandingobjectclass;

public class MainStudent {

	public static void main(String[] args) {
		System.out.println("********************************************************************");
		Student St1 = new Student(1256, "Ramesh");
		String s1 = St1.toString();
		System.out.println(s1);
		System.out.println("-----------------------------------------------------------------------");
		Student St2 = new Student(4355, "Suresh");
		String s2 = St2.toString();
		System.out.println(s2);
		System.out.println("************************************************************************");

	}

}
