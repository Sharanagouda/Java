package understandingobjectclass;

public class Demo2 {

}
