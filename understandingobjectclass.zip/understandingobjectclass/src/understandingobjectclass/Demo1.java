package understandingobjectclass;

public class Demo1 {
	public static void main(String[] args) {
		System.out.println("***********************************************************");
		Object o1 = new Object();
		String s1 = o1.toString();
		System.out.println(s1);
		System.out.println("--------------------------------------------------------");
		Object o2 = new Object();
		String s2 = o2.toString();
		System.out.println(s2);
		System.out.println("************************************************************");

	}
}
