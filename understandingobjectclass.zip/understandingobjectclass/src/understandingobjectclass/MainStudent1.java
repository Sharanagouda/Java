package understandingobjectclass;

public class MainStudent1 {

	public static void main(String[] args) {
		System.out.println("***************************************************************");
		Student St1 = new Student(1324, "Ramesh");
		System.out.println(St1);
		System.out.println("-------------------------------------------------------------");
		Student St2 = new Student(5452, "Suresh");
		System.out.println(St2);
		System.out.println("************************************************************");

	}

}
