package understandingobjectclass;

public class MainDemo2 {

	public static void main(String[] args) {
		System.out.println("***********************************************************");
		Demo2 ref1 = new Demo2();
		String s1 = ref1.toString();
		System.out.println(s1);
		System.out.println("_____________________________________________________________-");

		Demo2 ref2 = new Demo2();
		String s2 = ref2.toString();
		System.out.println(s2);
		System.out.println("********************************************************");

	}

}
