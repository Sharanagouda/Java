package understandingobjectclass;

public class Demo4 {
	static int radNum = 35912745;

	Demo4() {
		radNum++;

	}

	public String toString() {
		return " Demo4 instance";

	}

	public int hashcode() {
		return radNum;
	}
}
