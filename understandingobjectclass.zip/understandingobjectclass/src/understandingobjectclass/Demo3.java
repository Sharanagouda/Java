package understandingobjectclass;

public class Demo3 {
	public String toString() {
		return "Demo3 instance";
	}
}
