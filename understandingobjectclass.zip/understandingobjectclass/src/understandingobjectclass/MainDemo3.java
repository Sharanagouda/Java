package understandingobjectclass;

public class MainDemo3 {
	public static void main(String[] args) {
		System.out.println("***********************************************************");
		Demo3 ref1 = new Demo3();
		String s1 = ref1.toString();
		System.out.println(s1);
		System.out.println("_____________________________________________________________-");

		Demo3 ref2 = new Demo3();
		String s2 = ref2.toString();
		System.out.println(s2);
		System.out.println("********************************************************");

	}
}
