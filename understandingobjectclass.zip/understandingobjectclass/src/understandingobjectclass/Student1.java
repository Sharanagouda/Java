package understandingobjectclass;

public class Student1 {
	int id;
	String name;

	Student1(int id, String name) {
		this.id = id;
		this.name = name;

	}

	public String toString() {
		return ("id:" + this.id + ", name:" + this.name);
	}

	public boolean equals(Object arg1) {
		boolean result = false;
		if (arg1 instanceof Student1) {
			Student1 r1 = (Student1) arg1;
			result = (this.id == r1.id);

		} else {
			System.out.println("Object passed is not Student type");

		}
		return result;
	}
}
