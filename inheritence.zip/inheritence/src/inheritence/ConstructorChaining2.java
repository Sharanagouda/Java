package inheritence;

public class ConstructorChaining2 {

	public static void main(String[] args) {
		System.out.println("--------------------------------------");
		ConstructorChaining1b ref1 = new ConstructorChaining1b();
		System.out.println("-----------------------------------");
	}

}
