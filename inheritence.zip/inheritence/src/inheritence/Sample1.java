package inheritence;

public class Sample1 {
	int k = 13;

	void test1() {
		System.out.println("Running test1() of Sample1");
	}

}
