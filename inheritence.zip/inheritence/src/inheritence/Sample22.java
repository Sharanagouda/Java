package inheritence;

public class Sample22 extends Sample21 {
	double d=23.56;
	void disp() {
		System.out.println("Running disp() of Sample2");
}
}