package inheritence;

public class ConstructorChaining1a extends ConstructorChaining1 {
	ConstructorChaining1a() {
		super();
		System.out.println("Running ConstructorChaining1a Constructor body");
		System.out.println("---------------------------------");

	}
}
