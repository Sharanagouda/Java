package inheritence;

public class Demo1MainClass {

	public static void main(String[] args) {
		System.out.println("---------------------------");
		Demo3 ref1 = new Demo3();
		System.out.println("-----------------------------");
	}

}
