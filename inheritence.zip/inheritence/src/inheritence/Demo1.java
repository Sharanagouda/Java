package inheritence;

public class Demo1 {
	Demo1() {
		System.out.println("Running Demo1 Constructor Body");
		System.out.println("-------------------------------");

	}

	Demo1(int k) {
		this();
		System.out.println("Running ing arg Constructor Body");
		System.out.println(" k value:" + k);
	}
}

class Demo2 extends Demo1 {
	Demo2() {
		super(23);// Call to int arg super class Constructor
		System.out.println("Running Demo2 constructor Body");
		System.out.println("----------------------------------");
	}
}

class Demo3 extends Demo2 {
	Demo3() {
		System.out.println("Running Demo3 Constructor Body");
	}
}