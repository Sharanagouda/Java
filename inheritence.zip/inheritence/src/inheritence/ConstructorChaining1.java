package inheritence;

public class ConstructorChaining1 {
	void ConstructorChaining1() {

		System.out.println("Running ConstructorChaining1() of Constructor Body");
		System.out.println("---------------------------------------");

	}
}
