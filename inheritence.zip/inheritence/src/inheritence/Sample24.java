package inheritence;

public class Sample24 extends Sample22 {

	char j;
	void view()
	{
		System.out.println("Running view() of Sample24");
	}
}
