package inheritence;

public class MainClass {

	public static void main(String[] args) {
		System.out.println("----------------------------------------------");
		Sample2 ref1=new Sample2();
		//Creating an object of Sample2 type
		
		//inherited member
		System.out.println("k value :"+ref1.k);
		ref1.test1();
		
		//own members
		System.out.println("d value :"+ref1.d);
		ref1.disp();
		
		System.out.println("-------------------------------------------------");
		
	
	}
}
