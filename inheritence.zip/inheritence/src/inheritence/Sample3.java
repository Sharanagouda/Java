package inheritence;

public class Sample3 {
int k=14;
void test1()
{
	System.out.println("Running test1() of Sample3 class");
	
}
}
