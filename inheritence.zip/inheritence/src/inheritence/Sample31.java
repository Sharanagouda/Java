package inheritence;

public class Sample31 extends Sample3
{
int k=26;
void disp()
{
	System.out.println("Super class k value :"+super.k);
	System.out.println("sub class k value :"+this.k);
}
}
