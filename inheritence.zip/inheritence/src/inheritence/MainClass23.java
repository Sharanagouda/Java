package inheritence;

public class MainClass23 {

	public static void main(String[] args) {
		System.out.println("----------------------------------");
		Sample24 ref1=new Sample24();
		System.out.println("k value :" + ref1.k);
		System.out.println("k value :" + ref1.k);
		System.out.println("k value :" + ref1.k);
		ref1.test1();
		ref1.disp();
		ref1.view();

		System.out.println("---------------------------------");
	}

}
