package inheritence;

public class Sample3MainClass {

	public static void main(String[] args) {
	System.out.println("----------------------------------------");
	Sample31 ref1=new Sample31();
	ref1.disp();
	System.out.println("-----------------------------------------");

	}

}
