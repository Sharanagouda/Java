package inheritence;

public class Sample2 extends Sample1
{
	double d=23.56;
	void disp() {
		System.out.println("Running disp() of Sample2");
	}
}
