package inheritence;

public class ConstructorChaining1b extends ConstructorChaining1a {
	ConstructorChaining1b() {
		super();
		System.out.println("Running ConstructorChaining1b Constructor Body");
		System.out.println("---------------------------------");
	}
}