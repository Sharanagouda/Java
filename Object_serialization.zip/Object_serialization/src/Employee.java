
import java.io.Serializable;
import java.io.Serializable.*;

public class Employee implements Serializable {
int id;
String name;
double sal;
 Employee(int id,String name,double sal){
this.id=id;
this.name=name;
this.sal=sal;

}
}
