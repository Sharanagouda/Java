import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.ObjectOutputStream;


public interface Demo {
	public static void main(String[] args) {
		System.out.println("------------------------------------");
		Employee emp=new Employee(1234,"Sahrana",1500.0);
		try{
			FilterOutputStream fileout=new FilterOutputStream("Employee.ser");
			ObjectOutputStream obj=new ObjectOutputStream(fileout);
			obj.writeObject(emp);
			obj.flush();
			fileout.flush();
			obj.close();
			fileout.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}


}
