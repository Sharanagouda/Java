package patterns;

public class Pattern7 {

	public static void main(String[] args) {
	
	}

}
