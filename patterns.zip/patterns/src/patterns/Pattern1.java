package patterns;

public class Pattern1 {

	public static void main(String[] args) {
	System.out.println("main method started");
	for(int i=1;i<=5;i++)
	{
		System.out.println(i);
	}
System.out.println("main method ended");
	}

}
