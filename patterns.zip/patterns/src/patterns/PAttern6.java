package patterns;

public class PAttern6 {

	public static void main(String ar[]) {
		int i, j, k = 1;
		System.out.println("Floyd's triangle");
		for (i = 1; i <= 6; i++) {
			for (j = 1; j <= i; j++) {
				if (j == 1 && j == 1)
					k = 1;
				else
					k += 1;
				System.out.print(k + " ");
			}
			System.out.print("\n");
		}
	}
}
