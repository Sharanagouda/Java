package patterns;

public class Pattern3 {

	public static void main(String[] args) {
	int line=4;
	int S = line-1;
	int num=1;
	while(line>0)
	{
		for(int i=1;i<=S;i++)
			System.out.println(" ");
		
		for(int j=1;j<=num;j++)
			System.out.print("*");
		line--;
		
		num=num+2;
		S--;
		System.out.println( );
	}
	

	}

}
